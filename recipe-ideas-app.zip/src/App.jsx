import { useState } from "react";
import { Heart } from "lucide-react";

const sampleRecipes = [
  {
    id: 1,
    name: "Spaghetti Carbonara",
    ingredients: ["spaghetti", "eggs", "bacon", "cheese"],
    image: "https://images.unsplash.com/photo-1589302168068-964664d93dc0",
  },
  {
    id: 2,
    name: "Avocado Toast",
    ingredients: ["avocado", "bread", "egg", "salt"],
    image: "https://images.unsplash.com/photo-1551218808-94e220e084d2",
  },
  {
    id: 3,
    name: "Chicken Stir Fry",
    ingredients: ["chicken", "broccoli", "soy sauce", "rice"],
    image: "https://images.unsplash.com/photo-1601050690597-9f5e6f9f3c64",
  },
  {
    id: 4,
    name: "Berry Smoothie",
    ingredients: ["berries", "banana", "milk", "honey"],
    image: "https://images.unsplash.com/photo-1510626176961-4b37d6af1f4a",
  },
];

export default function App() {
  const [search, setSearch] = useState("");
  const [favorites, setFavorites] = useState([]);

  const filteredRecipes = sampleRecipes.filter(
    (r) =>
      r.name.toLowerCase().includes(search.toLowerCase()) ||
      r.ingredients.some((ing) =>
        ing.toLowerCase().includes(search.toLowerCase())
      )
  );

  const toggleFavorite = (id) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 p-6">
      <h1 className="text-3xl font-bold text-center mb-6">🍳 Recipe Ideas</h1>

      <div className="max-w-md mx-auto mb-8">
        <input
          type="text"
          placeholder="Search by name or ingredient..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full p-3 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-emerald-400"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {filteredRecipes.map((recipe) => (
          <div
            key={recipe.id}
            className="bg-white rounded-2xl shadow hover:shadow-lg transition overflow-hidden"
          >
            <img
              src={recipe.image}
              alt={recipe.name}
              className="w-full h-40 object-cover"
            />
            <div className="p-4 flex justify-between items-center">
              <div>
                <h2 className="text-lg font-semibold">{recipe.name}</h2>
                <p className="text-sm text-gray-500">
                  {recipe.ingredients.join(", ")}
                </p>
              </div>
              <button
                onClick={() => toggleFavorite(recipe.id)}
                className={`p-2 rounded-full transition ${
                  favorites.includes(recipe.id)
                    ? "text-red-500"
                    : "text-gray-400 hover:text-red-400"
                }`}
              >
                <Heart
                  fill={favorites.includes(recipe.id) ? "currentColor" : "none"}
                />
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredRecipes.length === 0 && (
        <p className="text-center text-gray-500 mt-10">
          No recipes found. Try another search!
        </p>
      )}
    </div>
  );
}
